﻿// Javascript skeleton.
// Edit and adapt to your needs.
// The documentation of the NeoLoad Javascript API
// is available in the appendix of the documentation.

// Get variable value from VariableManager
var category = context.variableManager.getValue("Extracted_Category");
var product = context.variableManager.getValue("Extracted_productId");
var item = context.variableManager.getValue("Extracted_itemId");

if (item==null) {
        context.fail("Variable 'item' not found");
}

// Do some computation using the methods
// you defined in the JS Library
//var computedValue = myLibraryFunction(myVar);
logger.debug("Picked a: " + category + " The product is: " + product + " The item picked: " + item + " The LG used: " + context.currentLG.name);

// Inject the computed value in a runtime variable
//context.variableManager.setValue("computedVar",computedValue);
